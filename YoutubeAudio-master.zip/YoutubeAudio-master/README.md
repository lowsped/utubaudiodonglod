# YoutubeAudio
Youtube audio downloader

# APK
[YoutubeAudio.apk](https://yadi.sk/d/_s94J8N03LJmXD)

# Features
- Downloading audio from video
- Receiving data from other apps

# Screenshots
<img height="366" width="206"  src="https://github.com/AlexVolkow/YoutubeAudio/blob/master/screenshots/2.jpg"/> <img height="366" width="206"  src="https://github.com/AlexVolkow/YoutubeAudio/blob/master/screenshots/1.jpg"/>

# Library's
- ButterKnife
- Retrofit2
- Retrolambda
- Picasso
- ThreeTenABP
